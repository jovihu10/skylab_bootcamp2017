$('#send').on('click', function(){
	console.log('hola')
	var memory = $("#name").val();
console.log(memory)
});


